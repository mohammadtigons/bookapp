$(document).ready(function () {
   const logemail = $("#logemail")
   const SignupUsernameInput = $("#sginup-username")
   const passwordInput = $("#password")
   const SignupPsswordInput = $("#sginup-password")
   const emailInput = $("#email")
   const loginBtn = $(".login-btn")
   const signupBtn = $(".signupbtn")
   const convertBtn = $(".convert-btn")
   const SignupContainer = $(".Signup-container")
   const LoginContainer = $(".container")


   loginBtn.click(function () {
      let logemailVal = logemail.val()
      let passwordVal = passwordInput.val()
      if (logemailVal && passwordVal) {
         let userInfo = {
            email: logemailVal,
            password: passwordVal
         }
         fetch("https://blackhill360.ir/auth/", {
            method: 'POST',
            body: JSON.stringify(userInfo),
            headers: {
               'Content-Type': 'application/json'
            }
         })
            .then(response => response.json())
            .then(data => {
               if (data.token) {
                 
                  const token = data.token;
                  fetch("https://blackhill360.ir/auth/", {
                     method: 'GET',
                     headers: {
                        'Authorization': `token ${token}`
                     }
                  })
                     .then(response => response.json()).then(data => {
                        
                         Swal.fire(
                     'Successfull',
                     `${data.user} successfully Loged in`,
                     'success'
                  )
                     }

                     )
                     .catch(error => {
                        console.log(error)
                     });




               } else {
                  Swal.fire(
                     'Failed',
                     'This account does not exist',
                     'error'
                  )
               }
            })
            .catch(error =>
               Swal.fire(
                  'Problem',
                  error,
                  'warning'
               ));


         logemail.val('');
         passwordInput.val('');
      } else (
         Swal.fire(
            'Empty Input',
            'Please enter your username and password',
            'warning'
         )
      )
   });





   signupBtn.click(function (event) {
      event.preventDefault()
      let usernameVal = SignupUsernameInput.val()
      let passwordVal = SignupPsswordInput.val()
      let emailVal = emailInput.val()

      if (usernameVal && passwordVal && emailVal) {
         let userInfo = {
            email: emailVal,
            username: usernameVal,
            password: passwordVal
         };
         fetch("https://blackhill360.ir/api/", {
            method: 'POST',
            body: JSON.stringify(userInfo),
            headers: {
               'Content-Type': 'application/json'
            }
         })
            .then(response => response.json())
            .then(data =>
               Swal.fire(
                  'Successfull',
                  'You Successfully Signed in ',
                  'success'
               ))
            .catch(error =>
               Swal.fire(
                  'Failed',
                  'Sign in failed',
                  'error'
               ));
         SignupUsernameInput.val('');
         SignupPsswordInput.val('');
         emailInput.val('');

      } else (
         Swal.fire(
            'Empty Input',
            'Please enter your username and password',
            'warning'
         )
      )

   });


   convertBtn.click(function () {
      LoginContainer.toggleClass('convert');
      SignupContainer.toggleClass('convert');
      SignupUsernameInput.val('');
      SignupPsswordInput.val('');
      emailInput.val('');
      emailInput.val('');
      logemail.val('');
      passwordInput.val('');
   })
});
