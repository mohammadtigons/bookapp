# from django.contrib import admin
# from .models import Article 
# class Aticlemodel(admin.ModelAdmin):
#     list_filter=("title","description")
#     list_display=("title","description")
from django.contrib import admin
# from .models import User 
# admin.site.register(User)