from django.conf import settings
from django.http import JsonResponse
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from selenium.webdriver.chrome.options import Options
        
# def search_with_selenium(request):
#     if request.method == 'POST':
#         search_text = request.POST.get('search_text')
#         driver = webdriver.Chrome() 
#         driver.get('https://www.google.com')
#         search_results = driver.find_element(By.CSS_SELECTOR,"textarea[class='gLFyf']")
#         search_results.send_keys(search_text)
#         search_results.submit()
#         time.sleep(20)
#         driver.quit()
#         return JsonResponse({'results': "this is good"})

#     return JsonResponse({'error': 'Invalid request'})

# @csrf_exempt  
# def search_view(request):
#     if request.method == 'GET':
#       driver_path =settings.WEBDRIVER_PATH
#       driver= webdriver.Chrome()
#       driver.get('https://www.google.com')
#       driver.quit()
#     elif request.method == 'POST':

#         post_data =  request.POST.get('post')
#         post_data = json.loads(request.body.decode('utf-8'))
#         driver= webdriver.Chrome('/home/blackhil/project2/webdriver/chromedriver')
#         driver.get('https://www.google.com')
#         # # time.sleep(5)
#         # # search_results = driver.find_element(By.CSS_SELECTOR,"textarea[class='gLFyf']")
#         # # search_results.send_keys(post_data)
#         # # search_results.submit()
#         # # time.sleep(5)
#         # # elements = driver.find_element(By.CSS_SELECTOR,"a[class='X5OiLe']")
#         # # href_code = elements.get_attribute("href")
#         driver.quit()
#         response_data = {
#             "message": "This is a POST request",
#             "data":post_data
#         }
        
#         return HttpResponse(json.dumps(response_data), content_type="application/json")


#     else:
#         return HttpResponse("Unsupported request method")



def my_view(request):
    # Configure Chrome WebDriver
    driver_path = settings.WEBDRIVER_PATH
    options = webdriver.ChromeOptions()
    options.add_argument(*settings.SELENIUM_OPTIONS)
    driver = webdriver.Chrome(executable_path=driver_path, options=options)

    try:
        # Perform desired actions using the WebDriver
        driver.get('https://www.google.com')
        page_title = driver.title
        return HttpResponse(f"Page title: {page_title}")

    finally:
        # Quit the WebDriver and clean up resources
        driver.quit()



#